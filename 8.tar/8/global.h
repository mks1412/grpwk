#define T_LEN 105000
#define S_SIZE 20000
#define S_LEN 25
