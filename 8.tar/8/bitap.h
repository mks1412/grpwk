int bitap_search(const char*, const char*, int);
